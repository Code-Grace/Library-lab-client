'use strict';

const example = require('../assets/scripts/example');

describe('Example', function () {
  it('is true', function () {
    expect(example).toBe(true);
  });
});
